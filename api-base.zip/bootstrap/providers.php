<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\TelescopeServiceProvider::class,
    LaravelJsonApi\Laravel\ServiceProvider::class,
];
