<?php

namespace Modules\User\Http\Controllers\Api\V1;

use LaravelJsonApi\Laravel\Http\Controllers\JsonApiController;

class UserController extends JsonApiController
{

}
