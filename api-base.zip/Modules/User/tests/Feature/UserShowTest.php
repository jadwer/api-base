<?php

namespace Modules\User\Tests\Feature;

use Modules\User\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UserShowTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        // Ejecuta el seeder de roles
        $this->artisan('db:seed', [
            '--class' => 'Modules\\User\\Database\\Seeders\\RoleSeeder',
        ]);
    }

    public function test_authenticated_user_can_view_another_user()
    {
        $authUser = User::factory()->create();
        $authUser->assignRole('god'); // Rol con acceso completo

        $targetUser = User::factory()->create([
            'name' => 'Gabino Ramírez',
            'email' => 'gabino@example.com',
            'status' => 'active',
        ]);

        $this->actingAs($authUser, 'sanctum');

        $response = $this->getJson(
            "/api/v1/users/{$targetUser->id}",
            ['Accept' => 'application/vnd.api+json']
        );

        $response->assertOk();

        $response->assertJson([
            'data' => [
                'id' => (string) $targetUser->id,
                'type' => 'users',
                'attributes' => [
                    'name' => 'Gabino Ramírez',
                    'email' => 'gabino@example.com',
                    'status' => 'active',
                ]
            ]
        ]);
    }

    public function test_unauthenticated_user_cannot_view_user()
    {
        $targetUser = User::factory()->create();

        $response = $this->getJson(
            "/api/v1/users/{$targetUser->id}",
            ['Accept' => 'application/vnd.api+json']
        );

        $response->assertUnauthorized(); // 401
    }
}
