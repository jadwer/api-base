<?php

namespace Modules\User\Tests\Feature;

use Tests\TestCase;
use Modules\User\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class UserIndexTest extends TestCase
{
    use RefreshDatabase;

    /** @var \Modules\User\Models\User */
    protected $user;

    protected function setUp(): void
    {
        parent::setUp();

        // Seed roles y permisos
        $this->artisan('module:seed', ['module' => 'User']);

        // Crear usuario autenticado
        $this->user = User::factory()->create();
        $this->actingAs($this->user, 'sanctum');
    }

    public function it_returns_a_list_of_users()
    {
        User::factory()->count(5)->create();

        $response = $this->getJson('/api/v1/users');

        $response->assertOk();
        $response->dump();
        $response->assertJsonStructure([
            'data' => [
                '*' => [
                    'id', 'type', 'attributes' => [
                        'name',
                        'email',
                        'status',
                        'created_at',
                        'updated_at',
                    ]
                ]
            ]
        ]);
    }

    public function unauthenticated_user_cannot_access_users_list()
    {
        auth()->guard('sanctum')->logout();

        $response = $this->getJson('/api/v1/users');
        
        $response->assertUnauthorized();
    }
}
