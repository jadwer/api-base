<x-auth::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('auth.name') !!}</p>
</x-auth::layouts.master>
